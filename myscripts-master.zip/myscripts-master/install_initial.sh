#!/bin/bash

yum update -y
yum install git vim unzip wget telnet zip -y
