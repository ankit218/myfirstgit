
#################
#    Common     #
#################

1. mkdir /data
2. cd /data
3. yum install git -y
4. git clone https://github.com/nixvipin/myscripts.git
5. cd myscripts

###################
#       AWS       #
###################

====Client01====

1.  GiTclient (done)
2.  Jenkins (done)
3.  Java install (self)
4.  Maven install (done)
5.  Java & Maven Path (done)
6.  Puppet Server (done)
7.  Ansible (done)
8.  Salt Stack (waiting)
9.  Nagios Server (done)
10. Nagios NPRE server (done)

====Server01====

1.  HAProxy (done)
2.  Apache (done)
3.  Nginx (done)
4.  MySQL (done)
5.  Tomcat (done)
6.  Java Path (done)
7.  Puppet Agent (done)
8.  Nagios NPRE client (done)

====Jenkins====

1. build_code.sh (done)
2. deploy_code.sh (done)

################
#    Laptop    #
################

====Server01====

1.  Filebeat (done)
2.  Chef Workstation(done)
3.  SaltStack Master(done)
4.  Docker (done)

====Client01====

1.  Elastic search (done)
2.  Logstash (done)
3.  Kibana (done)
4.  Chef Server(done)
5.  SaltStack Agent minion(done)


